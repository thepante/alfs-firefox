var alfsPrefs={
  'position' : 'left',
  'width' : '24em',
  'height' : '60%',
  'shadow_intensity' : 0.1,
  'keybind_ctrl' : 1, // 1 = 'ctrl', 2 = 'alt', 0 = sortcut disabled
  'keybind_key' : 88, // any valid - visit https://keycode.info/ for values
  'debug' : false, // set to 'true' to watch it working on console / ctrl+shift+j
  'classic_mode' : true, // do not float. Firefox default behavior + keep content loaded
};
